import javax.swing.*;

public class Search extends JFrame {
    private JPanel searchPanel;
    private JLabel titleLabel;
    private JTextField searchBar;
    private JCheckBox history;
    private JCheckBox adventure;
    private JCheckBox comedy;
    private JCheckBox romance;
    private JCheckBox action;
    private JCheckBox drama;
    private JButton goButton;


    public Search()
    {
        super();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(searchPanel);
        this.pack();
    }
}
