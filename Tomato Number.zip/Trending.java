import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.*;

public class Trending extends JFrame {
    private JPanel trendingPanel;
    private JLabel titleLabel;
    private JButton filterButton;
    private JButton searchButton;
    //private JTable trendingTable;
    private JButton backButton;
    private JScrollBar scrollBar1;
    private JTable myTable;
    private JScrollPane tableScrollPane;


    public Trending()
    {
        super();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(trendingPanel);
        this.pack();
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Home home = new Home("Home page");
                home.setVisible(true);
                Trending.this.dispose();

            }
        });
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Search search = new Search();
                search.setVisible(true);
                Trending.this.dispose();
            }
        });
    }

    private String tomato (String content1, String content2){
        ArrayList<String> title1_cust = new ArrayList<String>(); // store the list of users that rate content1 4 or 5
        ArrayList<String> title2_cust = new ArrayList<String>(); // store the list of users that rate content1 4 or 5
        int num_title1 = 999; // replace with the actual number of content1 rating in customer rating csv
        int num_title2 = 999; // replace with the actual number of content1 rating in customer rating csv

        for(int i=0; i<num_title1; i++){ // iterate through all the content1 rating in the csv
            if(content1[i].rating == "4" ||content1[i].rating == "5"){ // if the rating is 4 or 5
                title1_cust.add(content1[i].customerid); // store that corresponding customer ID in the arraylist
            }
        }
        // finished finding all the customer that rate 4 or 5 to content1
        for(int i=0; i<num_title2; i++){ // iterate through all the content1 rating in the csv
            if(content2[i].rating == "4" ||content2[i].rating == "5"){ // if the rating is 4 or 5
                title2_cust.add(content2[i].customerid); // store that corresponding customer ID in the arraylist
            }
        }
        // finished finding all the customer that rate 4 or 5 to content2
        // compare to see if there is user rate 4 or 5 for both contents
        for(int i=0; i<title1_cust.size(); i++){
            for(int j=0; j<title2_cust.size(); j++){
                if(title1_cust.get(i)==title2_cust.get(i)){
                    return content1 + "->" + title1_cust.get(i) +"->"+content2;
                }
            }
        }
        // if there is no single user that both rate content1 and content2, keep looking deeper
        Map<String, ArrayList<String>> content1_user_level1 = new HashMap<>();
        // the first String variable store the customer ID,
        // and the second variable store list of contents that rate by customer

        for(int i=0; i<title1_cust.size(); i++){
            content1_user_level1.put(title1_cust.get(i), new ArrayList<String>());
            // put the key (customer id) into the hashmap and initialize a new ArrayList for each key
            while (/* iterate through all the contents that this customer has rated */){
                content1_user_level1.get(title1_cust.get(i)).add("current index of content");
                // add all the contents that customer has rated 4 or 5 in a ArrayList
            }
        }
        // content1_user_level1 (key, value): key contains customers ID; value contains list of contents that rate by each user

        Map<String, ArrayList<String>> content2_user_level1 = new HashMap<>();
        for(int i=0; i<title2_cust.size(); i++){
            content2_user_level1.put(title2_cust.get(i), new ArrayList<String>());
            // put the key (customer id) into the hashmap and initialize a new ArrayList for each key
            while (/* iterate through all the contents that this customer has rated */){
                content2_user_level1.get(title2_cust.get(i)).add("current index of content");
                // add all the contents that customer has rated 4 or 5 in a ArrayList
            }
        }
        // content2_user_level1 (key, value): key contains customers ID; value contains list of contents that rate by each user

        // compare it to see if content1_user_level1 and content2_user_level1 have user rate 4 or 5 in same content
        for(Map.Entry<String, ArrayList<String>> entry1 : content1_user_level1.entrySet()){
            for(int i=0; i< entry1.getValue().size(); i++){
                for(Map.Entry<String, ArrayList<String>> entry2 : content2_user_level1.entrySet()){
                    for(int j=0; j< entry1.getValue().size(); j++){

                        if(entry1.getValue().get(i) == entry2.getValue().get(j)){
                            return content1 + "->" + entry1.getKey() +"->"+entry1.getValue().get(i)+"->" + entry2.getKey()+"->" + content2;
                            //Content 1 -> User A -> Content X -> User B -> Content 2
                        }
                    }
                }
            }
        }



//        //HashMap<String, String> user_level1 = new HashMap<>();
//        Map<String, ArrayList<String>> user_level1 = new HashMap<>();
//        // the first String variable store the customer ID,
//        // and the second variable store list of contents that rate by customer
//
//        for(int i=0; i<title1_cust.size(); i++){
//            user_level1.put(title1_cust.get(i), new ArrayList<String>());
//            // put the key (customer id) into the hashmap and initialize a new ArrayList for each key
//            while (/* iterate through all the contents that this customer has rated */){
//                user_level1.get(title1_cust.get(i)).add("current index of content");
//                // add all the contents that customer has rated in a ArrayList
//            }
//        }
//        // user_level1 (key, value): key contains numbers of customers; value contains list of contents that rate by each user
//
//        for(Map.Entry<String, ArrayList<String>> entry : user_level1.entrySet()){
//            //using map.entry to iterate through the key(customer id) and value(list of contents id) in the hashmap
//            for(int i=0; i<entry.getValue().size(); i++){
//                if(entry.getValue().get(i) == content2 ){ // if the current index of customer also rate the content 2
//                    return content1 + "->" + entry.getKey() +"->"+content2; // return the following chain
//                }
//            }
//        }
//
//        // if there is not a single user that has rate the content 2 in the user_level1 map, then continue;
//        // Content1 -> userA ->Content X; Content X != Content 2
//
//
//        Map<String, ArrayList<String>> content_level2 = new HashMap<>();
//        // the key (string) is the content id
//        // the value (ArrayList) is the list of user that rate 4 or 5 to this content
//
//        for(Map.Entry<String, ArrayList<String>> entry : user_level1.entrySet()){
//            // iterate through the previous map again
//            for(int i=0; i<entry.getValue().size(); i++){ // iterate through all the contents it has, and find all the customer that rate 4 and 5 for each content
//                if(content_level2.containsKey(entry.getValue().get(i))){
//                    // to check if there is a duplicate key, if true skip to next iteration
//                    continue;
//                }
//                //add the new key to the map
//                content_level2.put(entry.getValue().get(i), new ArrayList<String>()); // entry.getValue().get(i), this represent content ID
//
//                // add all the customer id that rate 4 or 5 in the arraylist
//                for(int j=0; j<"number of rating in the csv"; j++){ // iterate through all the rating for current index of content in csv
//                    if("content"[j].rating == "4" ||"content"[j].rating == "5"){ // if the rating is 4 or 5
//                        content_level2.get(entry.getValue().get(i)).add("current row of the customer id");// store that corresponding customer ID in the arraylist
//                    }
//                }
//            }
//        }
//
//        // after we find all the customer that rate 4 or 5 for each content in the user_level1 map
//        // then we iterate through all the user id to see if one of them have rate content2 ; Content1 -> userA -> ContentX ->User
//
//        Map<String, ArrayList<String>> user_level2 = new HashMap<>();
//        // key is the user id, and value is the content that rate 4 or 5 by user
//
//        for(Map.Entry<String, ArrayList<String>> entry : content_level2.entrySet()){
//
//            for(int i=0; i<entry.getValue().size(); i++){ // iterate through all the user it has, and find all the content that rate 4 and 5 for each user
//                if(user_level2.containsKey(entry.getValue().get(i))){
//                    // to check if there is a duplicate key, if true skip to next iteration
//                    continue;
//                }
//                //add the new key to the map
//                user_level2.put(entry.getValue().get(i), new ArrayList<String>()); // entry.getValue().get(i), this represent customer ID
//
//                // add all the content id that rate 4 or 5 by each user in the arraylist
//                for(int j=0; j<"number of rating in the csv"; j++){ // iterate through all the rating for current index of content in csv
//                    if("content"[j].rating == "4" ||"content"[j].rating == "5"){ // if the rating is 4 or 5
//                        user_level2.get(entry.getValue().get(i)).add("current row of the content id");// store that corresponding customer ID in the arraylist
//                    }
//                }
//            }
//        }
//
//        // now check if there is one content in the value that is equal to content 2 in user level2 map
//
//        for(Map.Entry<String, ArrayList<String>> entry : user_level2.entrySet()){
//            //using map.entry to iterate through the key(customer id) and value(list of contents id) in the hashmap
//            for(int i=0; i<entry.getValue().size(); i++){ // iterate through all the content id in each key(customer id)
//                if(entry.getValue().get(i) == content2 ){ // if the current index of customer also rate the content 2
//                    // get the previous level customer id
//
//                    return content1 + "->" + entry.getKey() +"->"+content2; // return the following chain
//                }
//            }
//        }

        return "";
    }

    private void createUIComponents() {
        List<Object[]> list = new ArrayList<Object[]>();
        Object[] information = {"", "", "", "", ""};


        dbSetup my = new dbSetup();
        //Building the connection
        Connection conn = null;


        try {
            //Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:postgresql://csce-315-db.engr.tamu.edu/csce315_914_5_db",
                    my.user, my.pswd);
        } catch (Exception f) {
            f.printStackTrace();
            System.err.println(f.getClass().getName()+": "+f.getMessage());
            System.exit(0);
        }//end try catch
        System.out.println("Opened database successfully");
        String cus_lname = "";
        //  String username = "";
        try{
            //create a statement object
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            //create an SQL statement
            String sqlStatement = "SELECT title_id FROM customer_ratings WHERE customer_id = '" + Login.userInfoInt + "' LIMIT 5;";
            System.out.println(sqlStatement);
            //send statement to DBMS
            ResultSet result = stmt.executeQuery(sqlStatement);

            //OUTPUT
            System.out.println("Database");
            System.out.println("______________________________________");

//                        List<Object[]> list = new ArrayList<Object[]>();

            while (result.next()) {

//                            ArrayList<Integer> = new ArrayList<Integer>();


                String titleID = result.getString("title_id");

                String sqlStatement2 = "SELECT original_title, start_year, genres, average_rating, runtime_minutes FROM titles WHERE title_id = '" + titleID + "';";

                System.out.println(sqlStatement2);

                ResultSet result2 = stmt.executeQuery(sqlStatement2);

                while (result2.next()) {


                    String titleName = result2.getString("original_title");
                    String year = result2.getString("start_year");
                    String genre = result2.getString("genres");
                    String avgRev = result2.getString("average_rating");
                    String runtime = result2.getString("runtime_minutes");

                    Object[] output = {titleName, year, genre, avgRev, runtime};


                    for (int i = 0; i < 5; i++) {
                        information[i] = output[i];
                    }

                }

//                            result.first();

                list.add(information);

                System.out.println("GOT TO THE END!");


            }

        } catch (Exception f){
            System.out.println("Error accessing Database.");
        }


//                    Recommended rec = new Recommended();
//                    rec.setVisible(true);
//                    Login.this.dispose();



//        Object[] information = {"A Bridge Too Far", "1977", "Drama,History,War", "7.4", "175"};
//        List<Object[]> list = new ArrayList<Object[]>();
//        list.add(information);

        Object[][] data = list.toArray(new Object[list.size()][5]);



        String[] columnNames = {"Title", "Year", "Genre", "Avg Review", "Runtime"};
//        Object[][] data = {{"A Bridge Too Far", "1977", "Drama,History,War", "7.4", "175"}, {"A Christmas Carol", "2019", "Drama,Fantasy,Music", "5.8", "75"}};
        myTable = new JTable(data, columnNames);
        myTable.setFillsViewportHeight(true);
        myTable.setEnabled(false);
    }
}
