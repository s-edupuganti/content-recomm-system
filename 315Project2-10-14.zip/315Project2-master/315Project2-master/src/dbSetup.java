/*
CSCE 315
Database setup example
Purpose: Keeping usernames and password private.
*/
public final class dbSetup  {
  public static final String user = "csce315_914_5_user";
  public static final String pswd = "group5";
}//end class
