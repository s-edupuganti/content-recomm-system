import javax.swing.*;
import javax.swing.text.View;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewerTrending extends JFrame {
    private JPanel vTrendingPanel;
    private JLabel titleLabel;
    private JButton searchButton;
    private JTable trendingTable;
    private JButton nextButton;
    private JButton backButton;
    private JButton back_home;
    private JScrollBar scrollBar1;


    public ViewerTrending()
    {
        super();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(vTrendingPanel);
        this.pack();

        // use this.validate() and this.repaint() to refresh the table or database after a command

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Recommended rec = new Recommended();
                rec.setVisible(true);
                ViewerTrending.this.dispose();
            }
        });
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Search search = new Search();
                search.setVisible(true);
                ViewerTrending.this.dispose();
            }
        });
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                WatchHistory wh = new WatchHistory();
                wh.setVisible(true);
                ViewerTrending.this.dispose();
            }
        });
        back_home.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Home home = new Home("Home page");
                home.setVisible(true);
                ViewerTrending.this.dispose();
            }
        });
    }
}
