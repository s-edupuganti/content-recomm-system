import javax.swing.*;
import javax.swing.text.View;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame {
    private JPanel recommendedPanel;
    private JTable recTable;
    private JButton nextButton;
    private JButton backButton;
    private JButton back_home;
    private JPanel Login_Panel;
    private JButton searchButton;
    private JLabel titleLabel;
    private JPasswordField passwordField1;
    private JPanel Main_panel;
    private JButton goButton;

    public Login() {
        super();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(Login_Panel);
        this.pack();
        back_home.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Home home = new Home("Home page");
                home.setVisible(true);
                Login.this.dispose();
            }
        });
        //Recommended rec = new Recommended();
        //rec.setVisible(true);
        goButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Recommended rec = new Recommended();
                rec.setVisible(true);
                Login.this.dispose();
            }
        });
    }
}
